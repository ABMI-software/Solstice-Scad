/**
 * sensors.cpp - Implémentation de la gestion des capteurs de température
 */

 #include <Arduino.h>
 #include "hardware.h"
 #include "sensors.h"
 
 // Instances des capteurs MAX6675
 MAX6675 thermocouple1(SENSOR_SCK, SENSOR1_CS, SENSOR_MISO);
 MAX6675 thermocouple2(SENSOR_SCK, SENSOR2_CS, SENSOR_MISO);
 MAX6675 thermocouple3(SENSOR_SCK, SENSOR3_CS, SENSOR_MISO);
 MAX6675 thermocouple4(SENSOR_SCK, SENSOR4_CS, SENSOR_MISO);
 
 // Tableau pour stocker les températures
 float temperatures[NUM_SENSORS] = {0.0, 0.0, 0.0, 0.0};
 
 /**
  * Initialise les capteurs de température
  */
 void initSensors() {
   // Attente pour que les capteurs soient prêts
   delay(500);
   
   // Première lecture pour vérifier que les capteurs sont opérationnels
   readAllTemperatures();
   
   Serial.println(F("Capteurs de température initialisés"));
 }
 
 /**
  * Lit toutes les températures et les stocke dans le tableau
  */
 void readAllTemperatures() {
   // Lecture des capteurs avec délai entre les lectures pour éviter les interférences
   temperatures[0] = thermocouple1.readCelsius();
   delay(10); // Court délai entre les lectures
   temperatures[1] = thermocouple2.readCelsius();
   delay(10);
   temperatures[2] = thermocouple3.readCelsius();
   delay(10);
   temperatures[3] = thermocouple4.readCelsius();
   
   // Détection des valeurs aberrantes (erreur de lecture)
   for (uint8_t i = 0; i < NUM_SENSORS; i++) {
     if (isnan(temperatures[i]) || temperatures[i] < -10.0 || temperatures[i] > 1000.0) {
       Serial.print(F("Erreur de lecture sur le capteur "));
       Serial.println(i + 1);
       // Conserver la dernière valeur valide
     }
   }
 }
 
 /**
  * Retourne la température d'un capteur spécifique
  */
 float getTemperature(uint8_t sensorIndex) {
   if (sensorIndex < NUM_SENSORS) {
     return temperatures[sensorIndex];
   }
   return 0.0; // Retourne 0 si l'index est invalide
 }
 
 /**
  * Affiche les données des capteurs sur le port série (débogage)
  */
 void printSensorData() {
   Serial.println(F("--- Données des capteurs ---"));
   for (uint8_t i = 0; i < NUM_SENSORS; i++) {
     Serial.print(F("Température "));
     Serial.print(i + 1);
     Serial.print(F(": "));
     Serial.print(temperatures[i]);
     Serial.println(F(" °C"));
   }
 }
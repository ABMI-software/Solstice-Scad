/**
 * hardware.h - Définition des constantes et des broches pour le projet
 */

#ifndef HARDWARE_H
#define HARDWARE_H

// Configuration des broches pour les modules MAX6675 (CAPTEURS)
// Chaque module MAX6675 nécessite 3 broches: CS, SCK, MISO
// SCK et MISO sont partagés sur la bus SPI
#define SENSOR_SCK 52  // Broche SCK partagée
#define SENSOR_MISO 50 // Broche MISO partagée
#define SENSOR1_CS 22  // Broche CS pour SENSOR 1
#define SENSOR2_CS 24  // Broche CS pour SENSOR 2
#define SENSOR3_CS 26  // Broche CS pour SENSOR 3
#define SENSOR4_CS 28  // Broche CS pour SENSOR 4

// Configuration des broches pour les encodeurs rotatifs KY-040
#define ENCODER1_CLK 2  // Broche CLK de l'encodeur 1 (interrupt)
#define ENCODER1_DT 3   // Broche DT de l'encodeur 1
#define ENCODER1_SW 4   // Broche SW (bouton) de l'encodeur 1
#define ENCODER2_CLK 18 // Broche CLK de l'encodeur 2 (interrupt)
#define ENCODER2_DT 19  // Broche DT de l'encodeur 2
#define ENCODER2_SW 20  // Broche SW (bouton) de l'encodeur 2

// Configuration des broches pour le driver de moteur L298N
#define PUMP1_ENA 8    // Broche PWM pour la vitesse de la pompe 1
#define PUMP1_IN1 9    // Broche de contrôle 1 pour de la pompe 1
#define PUMP1_IN2 10   // Broche de contrôle 2 pour de la pompe 1
#define PUMP2_ENB 11   // Broche PWM pour la vitesse de la pompe 2
#define PUMP2_IN3 12   // Broche de contrôle 1 pour de la pompe 2
#define Pump2_IN4 13   // Broche de contrôle 2 pour de la pompe 2

// Configuration des broches pour l'écran OLED I2C
// Utilise les broches SDA et SCL standard de l'Arduino Mega
#define OLED_RESET -1   // Partage reset avec Arduino
#define SCREEN_WIDTH 128 // Largeur de l'écran OLED en pixels
#define SCREEN_HEIGHT 64 // Hauteur de l'écran OLED en pixels
#define OLED_ADDRESS 0x3C // Adresse I2C de l'écran OLED (généralement 0x3C ou 0x3D)

// Configuration des broches pour le module carte SD
#define SD_CS 53        // Broche CS pour la carte SD

// Autres constantes
#define PWM_MIN 0       // Valeur PWM minimale
#define PWM_MAX 255     // Valeur PWM maximale
#define ENCODER_STEPS 20 // Nombre de pas pour un tour complet de l'encodeur

// Prototypes des fonctions
void initHardware();

#endif